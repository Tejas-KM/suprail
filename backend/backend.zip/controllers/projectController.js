import Project from '../models/Project.js';
import moment from 'moment';

export const createProject = async (req, res) => {
  try {
    const { predictionData } = req.body;
    const image = req.file;

    if (!image) {
      return res.status(400).json({ error: 'No image file provided' });
    }

    // Get today's date
    const today = moment().format('YYYYMMDD');
    const prefix = `PIPE-${today}`;

    // Count how many projects already created today
    const todayRegex = new RegExp(`^${prefix}-\\d{3}$`);
    const count = await Project.countDocuments({ name: todayRegex });

    // Generate name like PIPE-20250712-001
    const paddedCount = String(count + 1).padStart(3, '0');
    const generatedName = `${prefix}-${paddedCount}`;

    // Log it for debug
    console.log('Generated name:', generatedName);

    const project = new Project({
      name: generatedName,
      imageUrl: image.filename,
      predictionData: JSON.parse(predictionData),
    });

    await project.save();

    res.status(201).json(project);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create project' });
  }
};



export const getProjects = async (req, res) => {
  try {
    const { search = "", page = 1, limit = 4 } = req.query;

    const query = search
      ? { name: { $regex: search, $options: "i" } } // case-insensitive search
      : {};

    const skip = (parseInt(page) - 1) * parseInt(limit);

    // Fetch paginated data
    const projects = await Project.find(query)
      .select("name createdAt")
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    // Total count for pagination
    const total = await Project.countDocuments(query);

    res.status(200).json({ data: projects, total });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch projects" });
  }
};


export const getProjectById = async (req, res) => {
  try {
    const project = await Project.findById(req.params.id);

    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    // Construct full image URL (adjust domain as needed)
    const imageUrl = `${req.protocol}://${req.get('host')}/uploads/${project.imageUrl}`;

    res.status(200).json({
      _id: project._id,
      name: project.name,
      createdAt: project.createdAt,
      predictionData: project.predictionData,
      imageUrl,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch project' });
  }
};

export const updatePredictionData = async (req, res) => {
  try {
    const { predictionData, productCount } = req.body;

    // Validate input
    if (!predictionData) {
      return res.status(400).json({ error: 'predictionData is required' });
    }

     const transformedProductCount = Object.entries(productCount).map(([name, count]) => ({
      name,
      count
    }));

    // Find and update the project
    const project = await Project.findByIdAndUpdate(
      req.params.id,
      { 'predictionData.coordinates': predictionData, productCount: transformedProductCount },
      { new: true } // return the updated document
    );

    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    res.status(200).json({
      message: 'Prediction data updated successfully',
      project,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to update prediction data' });
  }
};

