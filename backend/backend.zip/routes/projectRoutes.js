import express from 'express';
import { createProject, getProjectById, getProjects, updatePredictionData } from '../controllers/projectController.js';
import { upload } from '../middleware/upload.js';

const router = express.Router();

router.post('/', upload.single('image'), createProject);
router.get('/', getProjects);
router.put('/:id/prediction', updatePredictionData);
router.get('/:id', getProjectById);

export default router;
